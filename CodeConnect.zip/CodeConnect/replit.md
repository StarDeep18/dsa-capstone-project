# CodeConnect - Collaborative DSA Learning Platform

## Overview

CodeConnect is a comprehensive coding practice and learning platform designed to help users master Data Structures and Algorithms (DSA) and prepare for technical interviews. The platform combines individual practice, competitive analytics, peer comparison, and interview preparation resources into a unified system. Users can solve coding problems in multiple languages (Python, Java, C), track their progress, compete on leaderboards, compare performance with peers, and access real interview experiences shared by the community.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Build System**
- React with TypeScript as the primary UI framework
- Vite for fast development and optimized production builds
- Wouter for lightweight client-side routing
- TanStack React Query for server state management and data fetching

**UI Component System**
- Shadcn/ui components based on Radix UI primitives
- Tailwind CSS for styling with custom design tokens
- Material Design inspired approach with coding platform best practices (LeetCode/HackerRank style)
- Dark mode as primary theme with light mode support
- Design philosophy: clarity over decoration, scannable information hierarchy, code-first readability

**State Management Strategy**
- React Query handles all server state (problems, submissions, leaderboard data)
- Local component state for UI interactions
- Theme state persisted to localStorage
- No global state management library needed due to server-driven architecture

**Key UI Patterns**
- Card-based layouts for problem listings and statistics
- Badge system for difficulty levels (easy/medium/hard) with semantic colors
- Progress bars and metrics visualization for user analytics
- Code editor interface with language selection (Python, Java, C)
- Real-time submission feedback with test case results

### Backend Architecture

**Server Framework**
- Express.js on Node.js for API server
- TypeScript for type safety across the stack
- RESTful API design pattern

**Authentication & Session Management**
- Replit Auth (OpenID Connect) for user authentication
- Passport.js strategy for OAuth flow
- PostgreSQL-backed session storage using connect-pg-simple
- Session-based authentication with secure HTTP-only cookies

**Code Execution System**
- Mock compiler service (placeholder for production Docker sandbox)
- Simulates code compilation and test case execution
- Returns structured results: status, passed test cases, execution metrics, complexity analysis
- Production design anticipates isolated Docker container execution for security

**API Structure**
- `/api/auth/*` - Authentication endpoints (login, logout, user info)
- `/api/problems/*` - Problem CRUD operations and submissions
- `/api/leaderboard` - Competitive ranking analytics
- `/api/compare` - User performance comparison
- `/api/dashboard` - Personal statistics
- `/api/interview-experiences/*` - Interview preparation resources

**Data Access Layer**
- Storage abstraction pattern (IStorage interface)
- DatabaseStorage implementation using Drizzle ORM
- All database operations isolated in storage module for testability

### Data Storage

**Database: PostgreSQL (via Neon)**
- Drizzle ORM for type-safe database queries
- Schema-first approach with TypeScript types generated from database schema

**Core Tables**
1. **users** - User profiles (id, email, name, profile image, timestamps)
2. **problems** - Coding problems (title, description, difficulty, topics, test cases, starter code)
3. **submissions** - User solution attempts (code, language, results, metrics, timestamps)
4. **interviewExperiences** - Community interview insights (company, role, topics, difficulty, experience)
5. **sessions** - Session storage for Replit Auth

**Data Relationships**
- Users have many submissions (one-to-many)
- Problems have many submissions (one-to-many)
- Users create interview experiences (one-to-many)
- Drizzle relations defined for type-safe joins

**Schema Validation**
- Zod schemas generated from Drizzle tables using drizzle-zod
- Runtime validation on API endpoints
- Type safety from database to API to frontend

### External Dependencies

**Authentication Service**
- Replit Auth (OpenID Connect provider)
- Handles user identity, OAuth flow, and token management
- Environment variables: REPL_ID, ISSUER_URL, SESSION_SECRET

**Database Service**
- Neon PostgreSQL (serverless PostgreSQL)
- WebSocket-based connection pooling for serverless environments
- Environment variable: DATABASE_URL
- Drizzle migrations stored in `/migrations` directory

**UI Component Libraries**
- Radix UI primitives (@radix-ui/react-*) for accessible components
- Lucide React for iconography
- Tailwind CSS for utility-first styling
- Google Fonts (Inter for UI, JetBrains Mono for code)

**Development Tools**
- Replit-specific Vite plugins (cartographer, dev-banner, runtime-error-modal)
- ESBuild for server bundling in production
- TypeScript compiler for type checking

**Mock External Service (Future Production)**
- Compiler Service (currently mocked in server/compiler-service.ts)
- Production will integrate with secure Docker sandbox at COMPILER_SERVICE_URL
- Handles actual code execution, compilation, and security isolation

**Key Environment Variables**
- DATABASE_URL - PostgreSQL connection string
- REPL_ID - Replit deployment identifier
- ISSUER_URL - OIDC provider endpoint
- SESSION_SECRET - Session encryption key
- COMPILER_SERVICE_URL - (Future) External code execution service
- NODE_ENV - Environment mode (development/production)