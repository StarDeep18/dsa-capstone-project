# CodeConnect Design Guidelines

## Design Approach: Hybrid System

**Primary Foundation:** Material Design + Coding Platform Best Practices (LeetCode, HackerRank)
**Justification:** CodeConnect is a utility-focused, information-dense learning platform where clarity, efficiency, and readability are paramount. Material Design provides excellent structure for complex data displays, while established coding platforms offer proven patterns for code editors, problem lists, and comparison interfaces.

**Key Design Principles:**
- Clarity over decoration: Every element serves a functional purpose
- Scannable information hierarchy: Users quickly find problems, metrics, and comparisons
- Code-first readability: Dark theme optimized for extended coding sessions
- Purposeful color usage: Status indicators and data visualization only

---

## Core Design Elements

### A. Color Palette

**Dark Mode (Primary):**
- Background Base: 220 15% 10% (deep blue-gray)
- Surface Elevated: 220 12% 15% (card backgrounds)
- Surface Interactive: 220 10% 20% (hover states)
- Text Primary: 0 0% 95% (high contrast white)
- Text Secondary: 220 5% 65% (muted descriptions)

**Accent Colors:**
- Primary Action: 210 100% 60% (vibrant blue for CTAs, links)
- Success/Solved: 142 76% 45% (green for completed problems)
- Warning/In Progress: 38 92% 50% (amber for partial completion)
- Error/Failed: 0 84% 60% (red for test failures)
- Difficulty Easy: 142 76% 45%
- Difficulty Medium: 38 92% 50%
- Difficulty Hard: 0 84% 60%

**Light Mode Adjustments:**
- Background: 0 0% 98%
- Surface: 0 0% 100%
- Text Primary: 220 15% 20%
- Keep accent colors consistent for status recognition

### B. Typography

**Font Families:**
- Interface: Inter (weights: 400, 500, 600) via Google Fonts
- Code/Monospace: JetBrains Mono (weights: 400, 500) via Google Fonts
- Headings: Inter (weight: 600)

**Type Scale:**
- Page Titles: text-3xl font-semibold (30px)
- Section Headers: text-xl font-semibold (20px)
- Card Titles: text-lg font-medium (18px)
- Body Text: text-base (16px)
- Code Snippets: text-sm font-mono (14px)
- Captions/Metadata: text-sm text-secondary (14px)
- Small Labels: text-xs (12px)

### C. Layout System

**Spacing Primitives:** Use Tailwind units of 2, 4, 6, and 8 consistently
- Component padding: p-4 or p-6
- Section gaps: gap-4 or gap-6
- Page margins: mx-4 md:mx-8 lg:mx-auto with max-w-7xl
- Card spacing: space-y-4

**Grid System:**
- Dashboard: 3-column grid (lg:grid-cols-3) for stats cards
- Problem List: 1-column with responsive table layout
- Comparison View: 2-column split (lg:grid-cols-2) for side-by-side
- Leaderboard: Single column with rank cards

**Container Strategy:**
- Maximum content width: max-w-7xl
- Code editor sections: Full-width with max-w-6xl inner container
- Forms and focused content: max-w-2xl

### D. Component Library

**Navigation:**
- Top Navigation Bar: Fixed header (h-16) with logo left, main nav center, user profile right
- Main Nav Items: Practice | Leaderboard | Compare | Interview Hub | Dashboard
- Active state: Bottom border (border-b-2 border-primary)

**Problem Cards:**
- Structure: Elevated surface with difficulty badge, title, topic tags, submission stats
- Layout: Flex with problem number/title left, difficulty/topics center, stats right
- Hover: Subtle lift (hover:translate-y-[-2px]) and border highlight

**Code Editor:**
- Monaco Editor-style interface with language selector dropdown
- Theme: VS Code Dark+ equivalent
- Line numbers: Visible with padding-left for code
- Submit button: Primary action bottom-right
- Test results: Expandable panel below editor

**Leaderboard Cards:**
- Rank badge: Circular indicator with rank number (top 3 get gold/silver/bronze accents)
- User info: Avatar (if available), username, solved count
- Metrics: Efficiency score, accuracy percentage displayed as progress bars
- Layout: Horizontal card with rank left, user center, metrics right

**Comparison Interface:**
- Split view: Two equal columns with user headers
- Solved problems: Venn diagram visualization with shared/unique counts
- Metrics table: Side-by-side efficiency and accuracy bars
- Problem lists: Scrollable sections showing unique and common problems

**Interview Experience Cards:**
- Company logo placeholder (round icon)
- Header: Company name, role, date
- Content: Question topics as tags, difficulty indicator, experience text preview
- Filter sidebar: Company search, topic checkboxes, difficulty range

**Data Visualization:**
- Progress Bars: Rounded (rounded-full) with gradient fills for metrics
- Stats Cards: Large number display with label, trend indicator (up/down arrow)
- Badges: Rounded-md with solid background for topics, outlined for filters

**Forms:**
- Input fields: Dark bg with lighter border, focus ring in primary color
- Labels: text-sm font-medium above inputs
- Buttons: Primary (solid blue), Secondary (outlined), Danger (red for delete)
- All form elements: Consistent h-10 or h-12 height

**Dashboard Widgets:**
- Recent Activity: Timeline-style list with problem titles and timestamps
- Performance Chart: Simple bar chart showing weekly problem-solving trend
- Quick Stats: Grid of metric cards (total solved, current streak, rank)

### E. Animations & Interactions

**Minimal Motion:**
- Card hovers: Subtle translate-y-[-2px] with transition-transform duration-200
- Button interactions: Built-in hover/active states only
- Page transitions: No animations
- Loading states: Simple spinner in primary color
- Data updates: Instant without fade effects

---

## Images & Iconography

**Icons:** Font Awesome (via CDN) for consistent UI icons
- Code icon for Practice section
- Trophy for Leaderboard
- Users-compare for Compare page
- Briefcase for Interview Hub
- Bar-chart for Dashboard

**Hero/Marketing:** No hero image needed - this is a utility application
**Avatars:** Circular placeholders (40px) for user profiles
**Company Logos:** 32px circular placeholders in interview cards
**Visual Elements:** Focus on data visualization (charts, graphs) over decorative imagery

---

## Page-Specific Guidelines

**Practice Page:** Problem table with filtering sidebar, compact rows showing difficulty badges and topic tags

**Leaderboard:** Vertical list of ranked user cards, top 3 highlighted with subtle background distinction

**Compare Page:** Input fields for two usernames at top, results in 2-column grid with Venn diagram for shared problems

**Interview Hub:** Filter sidebar left (companies, topics), scrollable experience cards right with search bar at top

**Dashboard:** 3-column stats grid at top, activity timeline and performance chart below in 2-column layout

This design creates a professional, efficient learning environment that prioritizes information clarity and code readability while maintaining visual polish through consistent spacing, purposeful color usage, and established UI patterns from successful coding platforms.