import { sql, relations } from 'drizzle-orm';
import {
  index,
  jsonb,
  pgTable,
  timestamp,
  varchar,
  integer,
  text,
  real,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// ===== SESSION STORAGE (REQUIRED FOR REPLIT AUTH) =====
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// ===== USER STORAGE (REQUIRED FOR REPLIT AUTH) =====
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;

// ===== PROBLEMS TABLE =====
export const problems = pgTable("problems", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  description: text("description").notNull(),
  difficulty: varchar("difficulty", { length: 20 }).notNull(), // easy, medium, hard
  topics: text("topics").array().notNull(), // ["arrays", "dynamic-programming"]
  testCases: jsonb("test_cases").notNull(), // Array of {input: string, expectedOutput: string}
  starterCode: jsonb("starter_code").notNull(), // {java: string, python: string, c: string}
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertProblemSchema = createInsertSchema(problems).omit({
  id: true,
  createdAt: true,
});

export type InsertProblem = z.infer<typeof insertProblemSchema>;
export type Problem = typeof problems.$inferSelect;

// ===== SUBMISSIONS TABLE =====
export const submissions = pgTable("submissions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  problemId: varchar("problem_id").notNull().references(() => problems.id, { onDelete: "cascade" }),
  code: text("code").notNull(),
  language: varchar("language", { length: 20 }).notNull(), // java, python, c
  status: varchar("status", { length: 20 }).notNull(), // accepted, wrong_answer, error
  timeComplexity: varchar("time_complexity", { length: 50 }), // O(n), O(n^2), etc
  spaceComplexity: varchar("space_complexity", { length: 50 }), // O(1), O(n), etc
  executionTime: real("execution_time"), // in milliseconds
  memoryUsed: real("memory_used"), // in MB
  passedTestCases: integer("passed_test_cases").notNull().default(0),
  totalTestCases: integer("total_test_cases").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertSubmissionSchema = createInsertSchema(submissions).omit({
  id: true,
  createdAt: true,
});

export type InsertSubmission = z.infer<typeof insertSubmissionSchema>;
export type Submission = typeof submissions.$inferSelect;

// ===== INTERVIEW EXPERIENCES TABLE =====
export const interviewExperiences = pgTable("interview_experiences", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  company: text("company").notNull(),
  role: text("role").notNull(),
  topics: text("topics").array().notNull(), // ["arrays", "system-design"]
  difficulty: varchar("difficulty", { length: 20 }).notNull(), // easy, medium, hard
  experience: text("experience").notNull(), // The detailed experience text
  interviewDate: timestamp("interview_date"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertInterviewExperienceSchema = createInsertSchema(interviewExperiences).omit({
  id: true,
  createdAt: true,
});

export type InsertInterviewExperience = z.infer<typeof insertInterviewExperienceSchema>;
export type InterviewExperience = typeof interviewExperiences.$inferSelect;

// ===== RELATIONS =====
export const usersRelations = relations(users, ({ many }) => ({
  submissions: many(submissions),
  interviewExperiences: many(interviewExperiences),
}));

export const problemsRelations = relations(problems, ({ many }) => ({
  submissions: many(submissions),
}));

export const submissionsRelations = relations(submissions, ({ one }) => ({
  user: one(users, {
    fields: [submissions.userId],
    references: [users.id],
  }),
  problem: one(problems, {
    fields: [submissions.problemId],
    references: [problems.id],
  }),
}));

export const interviewExperiencesRelations = relations(interviewExperiences, ({ one }) => ({
  user: one(users, {
    fields: [interviewExperiences.userId],
    references: [users.id],
  }),
}));
