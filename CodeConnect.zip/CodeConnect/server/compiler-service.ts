// Mock compiler service to simulate code execution
// In production, this would communicate with a secure Docker sandbox

interface TestCase {
  input: string;
  expectedOutput: string;
}

interface CompilationResult {
  status: 'accepted' | 'wrong_answer' | 'error';
  passedTestCases: number;
  totalTestCases: number;
  executionTime: number;
  memoryUsed: number;
  timeComplexity: string;
  spaceComplexity: string;
  error?: string;
}

export class MockCompilerService {
  async executeCode(
    code: string,
    language: string,
    testCases: TestCase[]
  ): Promise<CompilationResult> {
    // Simulate compilation/execution delay
    await new Promise(resolve => setTimeout(resolve, 500 + Math.random() * 1000));

    // Mock validation - check if code has basic structure
    const hasBasicStructure = code.trim().length > 20;
    
    if (!hasBasicStructure) {
      return {
        status: 'error',
        passedTestCases: 0,
        totalTestCases: testCases.length,
        executionTime: 0,
        memoryUsed: 0,
        timeComplexity: 'N/A',
        spaceComplexity: 'N/A',
        error: 'Code is too short or invalid',
      };
    }

    // Simulate test execution
    // In mock: randomly pass some test cases
    const passRate = 0.6 + Math.random() * 0.4; // 60-100% pass rate
    const passedCount = Math.floor(testCases.length * passRate);
    const allPassed = passedCount === testCases.length;

    // Mock complexity analysis based on code patterns
    const timeComplexity = this.analyzeTimeComplexity(code);
    const spaceComplexity = this.analyzeSpaceComplexity(code);

    // Mock execution metrics
    const executionTime = 50 + Math.random() * 950; // 50-1000ms
    const memoryUsed = 10 + Math.random() * 90; // 10-100 MB

    return {
      status: allPassed ? 'accepted' : 'wrong_answer',
      passedTestCases: passedCount,
      totalTestCases: testCases.length,
      executionTime,
      memoryUsed,
      timeComplexity,
      spaceComplexity,
    };
  }

  private analyzeTimeComplexity(code: string): string {
    const lowerCode = code.toLowerCase();
    
    if (lowerCode.includes('for') && lowerCode.includes('for', lowerCode.indexOf('for') + 1)) {
      return 'O(n²)';
    } else if (lowerCode.includes('while') || lowerCode.includes('for')) {
      return 'O(n)';
    } else if (lowerCode.includes('sort')) {
      return 'O(n log n)';
    } else {
      return 'O(1)';
    }
  }

  private analyzeSpaceComplexity(code: string): string {
    const lowerCode = code.toLowerCase();
    
    if (lowerCode.includes('[]') || lowerCode.includes('array') || lowerCode.includes('list')) {
      return 'O(n)';
    } else if (lowerCode.includes('dict') || lowerCode.includes('map') || lowerCode.includes('hashmap')) {
      return 'O(n)';
    } else {
      return 'O(1)';
    }
  }
}

export const compilerService = new MockCompilerService();
