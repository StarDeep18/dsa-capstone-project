import { storage } from "./storage";

const sampleProblems = [
  {
    title: "Two Sum",
    description: "Given an array of integers nums and an integer target, return indices of the two numbers such that they add up to target.\n\nYou may assume that each input would have exactly one solution, and you may not use the same element twice.\n\nExample:\nInput: nums = [2,7,11,15], target = 9\nOutput: [0,1]\nExplanation: Because nums[0] + nums[1] == 9, we return [0, 1].",
    difficulty: "easy",
    topics: ["arrays", "hash-table"],
    testCases: [
      { input: "[2,7,11,15], 9", expectedOutput: "[0,1]" },
      { input: "[3,2,4], 6", expectedOutput: "[1,2]" },
      { input: "[3,3], 6", expectedOutput: "[0,1]" },
    ],
    starterCode: {
      python: "def twoSum(nums, target):\n    # Write your code here\n    pass",
      java: "class Solution {\n    public int[] twoSum(int[] nums, int target) {\n        // Write your code here\n    }\n}",
      c: "int* twoSum(int* nums, int numsSize, int target, int* returnSize) {\n    // Write your code here\n}",
    },
  },
  {
    title: "Reverse Linked List",
    description: "Given the head of a singly linked list, reverse the list, and return the reversed list.\n\nExample:\nInput: head = [1,2,3,4,5]\nOutput: [5,4,3,2,1]",
    difficulty: "easy",
    topics: ["linked-list", "recursion"],
    testCases: [
      { input: "[1,2,3,4,5]", expectedOutput: "[5,4,3,2,1]" },
      { input: "[1,2]", expectedOutput: "[2,1]" },
      { input: "[]", expectedOutput: "[]" },
    ],
    starterCode: {
      python: "class ListNode:\n    def __init__(self, val=0, next=None):\n        self.val = val\n        self.next = next\n\ndef reverseList(head):\n    # Write your code here\n    pass",
      java: "class ListNode {\n    int val;\n    ListNode next;\n    ListNode(int val) { this.val = val; }\n}\n\nclass Solution {\n    public ListNode reverseList(ListNode head) {\n        // Write your code here\n    }\n}",
      c: "struct ListNode {\n    int val;\n    struct ListNode *next;\n};\n\nstruct ListNode* reverseList(struct ListNode* head) {\n    // Write your code here\n}",
    },
  },
  {
    title: "Longest Substring Without Repeating Characters",
    description: "Given a string s, find the length of the longest substring without repeating characters.\n\nExample:\nInput: s = \"abcabcbb\"\nOutput: 3\nExplanation: The answer is \"abc\", with the length of 3.",
    difficulty: "medium",
    topics: ["strings", "sliding-window", "hash-table"],
    testCases: [
      { input: "\"abcabcbb\"", expectedOutput: "3" },
      { input: "\"bbbbb\"", expectedOutput: "1" },
      { input: "\"pwwkew\"", expectedOutput: "3" },
    ],
    starterCode: {
      python: "def lengthOfLongestSubstring(s):\n    # Write your code here\n    pass",
      java: "class Solution {\n    public int lengthOfLongestSubstring(String s) {\n        // Write your code here\n    }\n}",
      c: "int lengthOfLongestSubstring(char* s) {\n    // Write your code here\n}",
    },
  },
  {
    title: "Maximum Subarray",
    description: "Given an integer array nums, find the subarray with the largest sum, and return its sum.\n\nExample:\nInput: nums = [-2,1,-3,4,-1,2,1,-5,4]\nOutput: 6\nExplanation: The subarray [4,-1,2,1] has the largest sum 6.",
    difficulty: "medium",
    topics: ["arrays", "dynamic-programming"],
    testCases: [
      { input: "[-2,1,-3,4,-1,2,1,-5,4]", expectedOutput: "6" },
      { input: "[1]", expectedOutput: "1" },
      { input: "[5,4,-1,7,8]", expectedOutput: "23" },
    ],
    starterCode: {
      python: "def maxSubArray(nums):\n    # Write your code here\n    pass",
      java: "class Solution {\n    public int maxSubArray(int[] nums) {\n        // Write your code here\n    }\n}",
      c: "int maxSubArray(int* nums, int numsSize) {\n    // Write your code here\n}",
    },
  },
  {
    title: "Merge K Sorted Lists",
    description: "You are given an array of k linked-lists lists, each linked-list is sorted in ascending order.\n\nMerge all the linked-lists into one sorted linked-list and return it.\n\nExample:\nInput: lists = [[1,4,5],[1,3,4],[2,6]]\nOutput: [1,1,2,3,4,4,5,6]",
    difficulty: "hard",
    topics: ["linked-list", "divide-and-conquer", "heap"],
    testCases: [
      { input: "[[1,4,5],[1,3,4],[2,6]]", expectedOutput: "[1,1,2,3,4,4,5,6]" },
      { input: "[]", expectedOutput: "[]" },
      { input: "[[]]", expectedOutput: "[]" },
    ],
    starterCode: {
      python: "class ListNode:\n    def __init__(self, val=0, next=None):\n        self.val = val\n        self.next = next\n\ndef mergeKLists(lists):\n    # Write your code here\n    pass",
      java: "class ListNode {\n    int val;\n    ListNode next;\n    ListNode(int val) { this.val = val; }\n}\n\nclass Solution {\n    public ListNode mergeKLists(ListNode[] lists) {\n        // Write your code here\n    }\n}",
      c: "struct ListNode {\n    int val;\n    struct ListNode *next;\n};\n\nstruct ListNode* mergeKLists(struct ListNode** lists, int listsSize) {\n    // Write your code here\n}",
    },
  },
  {
    title: "Median of Two Sorted Arrays",
    description: "Given two sorted arrays nums1 and nums2 of size m and n respectively, return the median of the two sorted arrays.\n\nThe overall run time complexity should be O(log (m+n)).\n\nExample:\nInput: nums1 = [1,3], nums2 = [2]\nOutput: 2.00000\nExplanation: merged array = [1,2,3] and median is 2.",
    difficulty: "hard",
    topics: ["arrays", "binary-search", "divide-and-conquer"],
    testCases: [
      { input: "[1,3], [2]", expectedOutput: "2.0" },
      { input: "[1,2], [3,4]", expectedOutput: "2.5" },
    ],
    starterCode: {
      python: "def findMedianSortedArrays(nums1, nums2):\n    # Write your code here\n    pass",
      java: "class Solution {\n    public double findMedianSortedArrays(int[] nums1, int[] nums2) {\n        // Write your code here\n    }\n}",
      c: "double findMedianSortedArrays(int* nums1, int nums1Size, int* nums2, int nums2Size) {\n    // Write your code here\n}",
    },
  },
];

export async function seedDatabase() {
  console.log("Seeding database with sample problems...");
  
  for (const problem of sampleProblems) {
    try {
      await storage.createProblem(problem);
      console.log(`Created problem: ${problem.title}`);
    } catch (error) {
      console.error(`Error creating problem ${problem.title}:`, error);
    }
  }
  
  console.log("Database seeding complete!");
}

// Run seed
seedDatabase()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error("Seeding failed:", error);
    process.exit(1);
  });
