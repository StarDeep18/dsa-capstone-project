import {
  users,
  problems,
  submissions,
  interviewExperiences,
  type User,
  type UpsertUser,
  type Problem,
  type InsertProblem,
  type Submission,
  type InsertSubmission,
  type InterviewExperience,
  type InsertInterviewExperience,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, sql } from "drizzle-orm";

export interface IStorage {
  // User operations (required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;

  // Problem operations
  getAllProblems(): Promise<Problem[]>;
  getProblem(id: string): Promise<Problem | undefined>;
  createProblem(problem: InsertProblem): Promise<Problem>;

  // Submission operations
  createSubmission(submission: InsertSubmission): Promise<Submission>;
  getUserSubmissions(userId: string, problemId?: string): Promise<Submission[]>;
  getProblemSubmissions(problemId: string): Promise<Submission[]>;

  // Interview experience operations
  getAllInterviewExperiences(): Promise<InterviewExperience[]>;
  createInterviewExperience(experience: InsertInterviewExperience): Promise<InterviewExperience>;

  // Analytics operations
  getLeaderboard(): Promise<any[]>;
  getDashboardStats(userId: string): Promise<any>;
  compareUsers(userId1: string, userId2: string): Promise<any>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Problem operations
  async getAllProblems(): Promise<Problem[]> {
    return await db.select().from(problems).orderBy(problems.createdAt);
  }

  async getProblem(id: string): Promise<Problem | undefined> {
    const [problem] = await db.select().from(problems).where(eq(problems.id, id));
    return problem;
  }

  async createProblem(problem: InsertProblem): Promise<Problem> {
    const [newProblem] = await db.insert(problems).values(problem).returning();
    return newProblem;
  }

  // Submission operations
  async createSubmission(submission: InsertSubmission): Promise<Submission> {
    const [newSubmission] = await db.insert(submissions).values(submission).returning();
    return newSubmission;
  }

  async getUserSubmissions(userId: string, problemId?: string): Promise<Submission[]> {
    if (problemId) {
      return await db
        .select()
        .from(submissions)
        .where(and(eq(submissions.userId, userId), eq(submissions.problemId, problemId)))
        .orderBy(desc(submissions.createdAt));
    }
    return await db
      .select()
      .from(submissions)
      .where(eq(submissions.userId, userId))
      .orderBy(desc(submissions.createdAt));
  }

  async getProblemSubmissions(problemId: string): Promise<Submission[]> {
    return await db
      .select()
      .from(submissions)
      .where(eq(submissions.problemId, problemId))
      .orderBy(desc(submissions.createdAt));
  }

  // Interview experience operations
  async getAllInterviewExperiences(): Promise<InterviewExperience[]> {
    return await db.select().from(interviewExperiences).orderBy(desc(interviewExperiences.createdAt));
  }

  async createInterviewExperience(experience: InsertInterviewExperience): Promise<InterviewExperience> {
    const [newExperience] = await db.insert(interviewExperiences).values(experience).returning();
    return newExperience;
  }

  // Analytics operations
  async getLeaderboard(): Promise<any[]> {
    const result = await db
      .select({
        userId: submissions.userId,
        solvedCount: sql<number>`COUNT(DISTINCT ${submissions.problemId})`.as('solved_count'),
        acceptedCount: sql<number>`COUNT(DISTINCT CASE WHEN ${submissions.status} = 'accepted' THEN ${submissions.problemId} END)`.as('accepted_count'),
        totalSubmissions: sql<number>`COUNT(*)`.as('total_submissions'),
        averageEfficiency: sql<number>`COALESCE(AVG(CASE WHEN ${submissions.executionTime} > 0 THEN 100.0 - (${submissions.executionTime} / 1000.0) END), 50)`.as('avg_efficiency'),
      })
      .from(submissions)
      .groupBy(submissions.userId);

    const leaderboardWithUsers = await Promise.all(
      result.map(async (entry) => {
        const user = await this.getUser(entry.userId);
        const accuracy = entry.totalSubmissions > 0 
          ? (entry.acceptedCount / entry.solvedCount) * 100 
          : 0;
        
        return {
          userId: entry.userId,
          user,
          solvedCount: entry.solvedCount,
          acceptedCount: entry.acceptedCount,
          averageEfficiency: Math.min(entry.averageEfficiency, 100),
          accuracy,
        };
      })
    );

    // Sort using efficient algorithm (similar to QuickSort performance)
    return leaderboardWithUsers.sort((a, b) => {
      const scoreA = a.solvedCount * 10 + a.averageEfficiency + a.accuracy;
      const scoreB = b.solvedCount * 10 + b.averageEfficiency + b.accuracy;
      return scoreB - scoreA;
    });
  }

  async getDashboardStats(userId: string): Promise<any> {
    const userSubmissions = await this.getUserSubmissions(userId);
    const uniqueProblems = new Set(userSubmissions.map(s => s.problemId));
    const acceptedSubmissions = userSubmissions.filter(s => s.status === 'accepted');
    const uniqueAccepted = new Set(acceptedSubmissions.map(s => s.problemId));

    return {
      totalSolved: uniqueProblems.size,
      totalAccepted: uniqueAccepted.size,
      accuracy: uniqueProblems.size > 0 ? (uniqueAccepted.size / uniqueProblems.size) * 100 : 0,
      recentSubmissions: userSubmissions.slice(0, 10),
    };
  }

  async compareUsers(userId1: string, userId2: string): Promise<any> {
    // Use Hash Sets for O(N) efficiency as mentioned in the requirements
    const user1Submissions = await this.getUserSubmissions(userId1);
    const user2Submissions = await this.getUserSubmissions(userId2);

    const user1Problems = new Set(user1Submissions.filter(s => s.status === 'accepted').map(s => s.problemId));
    const user2Problems = new Set(user2Submissions.filter(s => s.status === 'accepted').map(s => s.problemId));

    // Find shared problems using hash set intersection (O(N))
    const sharedProblems = Array.from(user1Problems).filter(p => user2Problems.has(p));
    const user1Unique = Array.from(user1Problems).filter(p => !user2Problems.has(p));
    const user2Unique = Array.from(user2Problems).filter(p => !user1Problems.has(p));

    const [user1, user2] = await Promise.all([
      this.getUser(userId1),
      this.getUser(userId2),
    ]);

    const user1Stats = await this.getDashboardStats(userId1);
    const user2Stats = await this.getDashboardStats(userId2);

    return {
      user1: {
        ...user1,
        solvedCount: user1Stats.totalSolved,
        acceptedCount: user1Stats.totalAccepted,
        accuracy: user1Stats.accuracy,
        uniqueProblems: user1Unique,
      },
      user2: {
        ...user2,
        solvedCount: user2Stats.totalSolved,
        acceptedCount: user2Stats.totalAccepted,
        accuracy: user2Stats.accuracy,
        uniqueProblems: user2Unique,
      },
      sharedProblems,
    };
  }
}

export const storage = new DatabaseStorage();
