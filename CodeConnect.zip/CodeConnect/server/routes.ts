import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { compilerService } from "./compiler-service";
import { insertProblemSchema, insertSubmissionSchema, insertInterviewExperienceSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Problem routes
  app.get("/api/problems", isAuthenticated, async (req, res) => {
    try {
      const problems = await storage.getAllProblems();
      res.json(problems);
    } catch (error) {
      console.error("Error fetching problems:", error);
      res.status(500).json({ message: "Failed to fetch problems" });
    }
  });

  app.get("/api/problems/:id", isAuthenticated, async (req, res) => {
    try {
      const problem = await storage.getProblem(req.params.id);
      if (!problem) {
        return res.status(404).json({ message: "Problem not found" });
      }
      res.json(problem);
    } catch (error) {
      console.error("Error fetching problem:", error);
      res.status(500).json({ message: "Failed to fetch problem" });
    }
  });

  app.post("/api/problems", isAuthenticated, async (req, res) => {
    try {
      const validated = insertProblemSchema.parse(req.body);
      const problem = await storage.createProblem(validated);
      res.json(problem);
    } catch (error: any) {
      console.error("Error creating problem:", error);
      res.status(400).json({ message: error.message || "Failed to create problem" });
    }
  });

  // Submission routes
  app.get("/api/submissions/:problemId", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const submissions = await storage.getUserSubmissions(userId, req.params.problemId);
      res.json(submissions);
    } catch (error) {
      console.error("Error fetching submissions:", error);
      res.status(500).json({ message: "Failed to fetch submissions" });
    }
  });

  app.post("/api/problems/:problemId/submit", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const problemId = req.params.problemId;
      const { code, language } = req.body;

      if (!code || !language) {
        return res.status(400).json({ message: "Code and language are required" });
      }

      // Get problem to access test cases
      const problem = await storage.getProblem(problemId);
      if (!problem) {
        return res.status(404).json({ message: "Problem not found" });
      }

      // Execute code using mock compiler service
      const testCases = problem.testCases as Array<{ input: string; expectedOutput: string }>;
      const result = await compilerService.executeCode(code, language, testCases);

      // Save submission
      const submission = await storage.createSubmission({
        userId,
        problemId,
        code,
        language,
        status: result.status,
        timeComplexity: result.timeComplexity,
        spaceComplexity: result.spaceComplexity,
        executionTime: result.executionTime,
        memoryUsed: result.memoryUsed,
        passedTestCases: result.passedTestCases,
        totalTestCases: result.totalTestCases,
      });

      res.json({ ...submission, ...result });
    } catch (error: any) {
      console.error("Error submitting code:", error);
      res.status(500).json({ message: error.message || "Failed to submit code" });
    }
  });

  // Leaderboard route (uses efficient sorting algorithm)
  app.get("/api/leaderboard", isAuthenticated, async (req, res) => {
    try {
      const leaderboard = await storage.getLeaderboard();
      res.json(leaderboard);
    } catch (error) {
      console.error("Error fetching leaderboard:", error);
      res.status(500).json({ message: "Failed to fetch leaderboard" });
    }
  });

  // Dashboard route
  app.get("/api/dashboard", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const stats = await storage.getDashboardStats(userId);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching dashboard stats:", error);
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });

  // Compare route (uses hash sets for O(N) efficiency)
  app.post("/api/compare", isAuthenticated, async (req, res) => {
    try {
      const { userId1, userId2 } = req.body;

      if (!userId1 || !userId2) {
        return res.status(400).json({ message: "Both user IDs are required" });
      }

      const comparison = await storage.compareUsers(userId1, userId2);
      res.json(comparison);
    } catch (error) {
      console.error("Error comparing users:", error);
      res.status(500).json({ message: "Failed to compare users" });
    }
  });

  // Interview experience routes
  app.get("/api/interview-experiences", isAuthenticated, async (req, res) => {
    try {
      const experiences = await storage.getAllInterviewExperiences();
      res.json(experiences);
    } catch (error) {
      console.error("Error fetching interview experiences:", error);
      res.status(500).json({ message: "Failed to fetch interview experiences" });
    }
  });

  app.post("/api/interview-experiences", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const validated = insertInterviewExperienceSchema.parse({
        ...req.body,
        userId,
      });
      const experience = await storage.createInterviewExperience(validated);
      res.json(experience);
    } catch (error: any) {
      console.error("Error creating interview experience:", error);
      res.status(400).json({ message: error.message || "Failed to create interview experience" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
