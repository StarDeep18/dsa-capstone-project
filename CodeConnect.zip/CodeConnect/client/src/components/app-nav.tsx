import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Code, Trophy, GitCompare, Briefcase, LayoutDashboard, LogOut } from "lucide-react";
import { ThemeToggle } from "./theme-toggle";

export function AppNav() {
  const [location] = useLocation();

  const navItems = [
    { path: "/practice", label: "Practice", icon: Code },
    { path: "/leaderboard", label: "Leaderboard", icon: Trophy },
    { path: "/compare", label: "Compare", icon: GitCompare },
    { path: "/interview-hub", label: "Interview Hub", icon: Briefcase },
    { path: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  ];

  return (
    <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        <div className="flex items-center gap-6">
          <a href="/practice" className="flex items-center gap-2">
            <Code className="h-6 w-6 text-primary" />
            <span className="text-xl font-semibold">CodeConnect</span>
          </a>
          <nav className="hidden md:flex items-center gap-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = location === item.path;
              return (
                <Button
                  key={item.path}
                  variant="ghost"
                  size="sm"
                  asChild
                  className={isActive ? "bg-accent" : ""}
                  data-testid={`nav-${item.path.slice(1)}`}
                >
                  <a href={item.path} className="flex items-center gap-2">
                    <Icon className="h-4 w-4" />
                    {item.label}
                  </a>
                </Button>
              );
            })}
          </nav>
        </div>
        <div className="flex items-center gap-2">
          <ThemeToggle />
          <Button
            variant="ghost"
            size="sm"
            asChild
            data-testid="button-logout"
          >
            <a href="/api/logout">
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </a>
          </Button>
        </div>
      </div>
      <nav className="md:hidden border-t px-4 py-2 flex gap-1 overflow-x-auto">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location === item.path;
          return (
            <Button
              key={item.path}
              variant="ghost"
              size="sm"
              asChild
              className={`flex-shrink-0 ${isActive ? "bg-accent" : ""}`}
            >
              <a href={item.path} className="flex items-center gap-2">
                <Icon className="h-4 w-4" />
                {item.label}
              </a>
            </Button>
          );
        })}
      </nav>
    </header>
  );
}
