import { useState } from "react";
import { useParams } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import type { Problem, Submission } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { ArrowLeft, Play, CheckCircle2, XCircle, Loader2 } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function SolveProblem() {
  const params = useParams();
  const problemId = params.id as string;
  const { toast } = useToast();
  
  const [language, setLanguage] = useState("python");
  const [code, setCode] = useState("");

  const { data: problem, isLoading } = useQuery<Problem>({
    queryKey: ["/api/problems", problemId],
  });

  const { data: submissions } = useQuery<Submission[]>({
    queryKey: ["/api/submissions", problemId],
  });

  const submitMutation = useMutation({
    mutationFn: async (data: { code: string; language: string }) => {
      const res = await apiRequest("POST", `/api/problems/${problemId}/submit`, data);
      return await res.json();
    },
    onSuccess: (result: any) => {
      queryClient.invalidateQueries({ queryKey: ["/api/submissions", problemId] });
      queryClient.invalidateQueries({ queryKey: ["/api/leaderboard"] });
      
      if (result.status === "accepted") {
        toast({
          title: "Success!",
          description: `All test cases passed! ${result.passedTestCases}/${result.totalTestCases}`,
        });
      } else {
        toast({
          title: "Try Again",
          description: `${result.passedTestCases}/${result.totalTestCases} test cases passed`,
          variant: "destructive",
        });
      }
    },
    onError: () => {
      toast({
        title: "Submission Failed",
        description: "An error occurred while submitting your code",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = () => {
    if (!code.trim()) {
      toast({
        title: "Empty Code",
        description: "Please write some code before submitting",
        variant: "destructive",
      });
      return;
    }
    submitMutation.mutate({ code, language });
  };

  const starterCode = problem?.starterCode as Record<string, string> | undefined;

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "easy":
        return "bg-chart-2/10 text-chart-2 border-chart-2/20";
      case "medium":
        return "bg-chart-3/10 text-chart-3 border-chart-3/20";
      case "hard":
        return "bg-chart-5/10 text-chart-5 border-chart-5/20";
      default:
        return "";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "accepted":
        return <CheckCircle2 className="h-4 w-4 text-chart-2" />;
      case "wrong_answer":
      case "error":
        return <XCircle className="h-4 w-4 text-chart-5" />;
      default:
        return null;
    }
  };

  if (isLoading) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!problem) {
    return (
      <div className="flex-1 flex items-center justify-center p-4">
        <Card className="max-w-md w-full">
          <CardContent className="p-6 text-center">
            <p className="text-muted-foreground">Problem not found</p>
            <Button asChild className="mt-4" data-testid="button-back-problems">
              <a href="/practice">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Problems
              </a>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-hidden flex flex-col lg:flex-row">
      <div className="lg:w-1/2 overflow-auto border-b lg:border-b-0 lg:border-r">
        <div className="p-4 md:p-6">
          <Button
            variant="ghost"
            size="sm"
            asChild
            className="mb-4"
            data-testid="button-back"
          >
            <a href="/practice">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back
            </a>
          </Button>

          <div className="mb-4">
            <div className="flex items-center gap-3 mb-3">
              <h1 className="text-2xl font-semibold">{problem.title}</h1>
              <Badge
                variant="outline"
                className={getDifficultyColor(problem.difficulty)}
                data-testid="badge-problem-difficulty"
              >
                {problem.difficulty}
              </Badge>
            </div>
            <div className="flex flex-wrap gap-2">
              {problem.topics.map((topic) => (
                <Badge key={topic} variant="secondary" className="text-xs">
                  {topic}
                </Badge>
              ))}
            </div>
          </div>

          <Card className="mb-4">
            <CardHeader>
              <CardTitle className="text-lg">Description</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground whitespace-pre-wrap">
                {problem.description}
              </p>
            </CardContent>
          </Card>

          {submissions && submissions.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Recent Submissions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {submissions.slice(0, 5).map((sub) => (
                  <div
                    key={sub.id}
                    className="flex items-center justify-between p-2 rounded-md bg-muted/50"
                    data-testid={`submission-${sub.id}`}
                  >
                    <div className="flex items-center gap-2">
                      {getStatusIcon(sub.status)}
                      <span className="text-sm font-mono">{sub.language}</span>
                      <span className="text-xs text-muted-foreground">
                        {sub.passedTestCases}/{sub.totalTestCases} passed
                      </span>
                    </div>
                    <span className="text-xs text-muted-foreground">
                      {new Date(sub.createdAt!).toLocaleString()}
                    </span>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      <div className="lg:w-1/2 flex flex-col overflow-hidden">
        <div className="border-b p-4 flex items-center justify-between gap-4">
          <Select value={language} onValueChange={setLanguage}>
            <SelectTrigger className="w-[140px]" data-testid="select-language">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="python">Python</SelectItem>
              <SelectItem value="java">Java</SelectItem>
              <SelectItem value="c">C</SelectItem>
            </SelectContent>
          </Select>
          <Button
            onClick={handleSubmit}
            disabled={submitMutation.isPending}
            data-testid="button-submit-code"
          >
            {submitMutation.isPending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Running...
              </>
            ) : (
              <>
                <Play className="mr-2 h-4 w-4" />
                Submit
              </>
            )}
          </Button>
        </div>

        <Tabs defaultValue="code" className="flex-1 flex flex-col overflow-hidden">
          <TabsList className="w-full justify-start rounded-none border-b bg-transparent px-4">
            <TabsTrigger value="code" data-testid="tab-code">Code</TabsTrigger>
            <TabsTrigger value="starter" data-testid="tab-starter">Starter Code</TabsTrigger>
          </TabsList>
          <TabsContent value="code" className="flex-1 overflow-auto m-0 p-4">
            <Textarea
              value={code}
              onChange={(e) => setCode(e.target.value)}
              placeholder={`Write your ${language} code here...`}
              className="min-h-[500px] font-mono text-sm resize-none"
              data-testid="textarea-code"
            />
          </TabsContent>
          <TabsContent value="starter" className="flex-1 overflow-auto m-0 p-4">
            <pre className="font-mono text-sm p-4 bg-muted rounded-md overflow-auto">
              <code>{starterCode?.[language] || "// No starter code available"}</code>
            </pre>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
