import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Trophy, Medal, Award, TrendingUp } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";

interface LeaderboardEntry {
  userId: string;
  user: {
    id: string;
    email: string | null;
    firstName: string | null;
    lastName: string | null;
    profileImageUrl: string | null;
  };
  solvedCount: number;
  acceptedCount: number;
  averageEfficiency: number;
  accuracy: number;
}

export default function Leaderboard() {
  const { data: leaderboard, isLoading } = useQuery<LeaderboardEntry[]>({
    queryKey: ["/api/leaderboard"],
  });

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Trophy className="h-6 w-6 text-chart-3" />;
      case 2:
        return <Medal className="h-6 w-6 text-muted-foreground" />;
      case 3:
        return <Award className="h-6 w-6 text-chart-5" />;
      default:
        return null;
    }
  };

  const getRankBadgeColor = (rank: number) => {
    switch (rank) {
      case 1:
        return "bg-chart-3/10 text-chart-3 border-chart-3/20";
      case 2:
        return "bg-muted text-muted-foreground border-border";
      case 3:
        return "bg-chart-5/10 text-chart-5 border-chart-5/20";
      default:
        return "";
    }
  };

  const getUserDisplayName = (user: LeaderboardEntry["user"]) => {
    if (user.firstName && user.lastName) {
      return `${user.firstName} ${user.lastName}`;
    }
    if (user.firstName) return user.firstName;
    if (user.email) return user.email.split("@")[0];
    return "Anonymous User";
  };

  const getUserInitials = (user: LeaderboardEntry["user"]) => {
    if (user.firstName && user.lastName) {
      return `${user.firstName[0]}${user.lastName[0]}`.toUpperCase();
    }
    if (user.firstName) return user.firstName.slice(0, 2).toUpperCase();
    if (user.email) return user.email.slice(0, 2).toUpperCase();
    return "??";
  };

  return (
    <div className="flex-1 overflow-auto p-4 md:p-6 lg:p-8">
      <div className="mx-auto max-w-5xl">
        <div className="mb-6">
          <h1 className="text-3xl font-semibold mb-2">Leaderboard</h1>
          <p className="text-muted-foreground">
            Top performers ranked by efficiency and accuracy
          </p>
        </div>

        <div className="space-y-4">
          {isLoading ? (
            Array.from({ length: 10 }).map((_, i) => (
              <Card key={i}>
                <CardContent className="p-4">
                  <div className="flex items-center gap-4">
                    <Skeleton className="h-12 w-12 rounded-full" />
                    <div className="flex-1">
                      <Skeleton className="h-5 w-32 mb-2" />
                      <Skeleton className="h-4 w-48" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : leaderboard && leaderboard.length > 0 ? (
            leaderboard.map((entry, index) => {
              const rank = index + 1;
              const isTopThree = rank <= 3;

              return (
                <Card
                  key={entry.userId}
                  className={`hover-elevate transition-all ${
                    isTopThree ? "border-primary/20" : ""
                  }`}
                  data-testid={`card-rank-${rank}`}
                >
                  <CardContent className="p-4">
                    <div className="flex items-center gap-4">
                      <div className="flex items-center justify-center min-w-[3rem]">
                        {isTopThree ? (
                          <div className="flex flex-col items-center gap-1">
                            {getRankIcon(rank)}
                            <Badge
                              variant="outline"
                              className={`text-xs ${getRankBadgeColor(rank)}`}
                              data-testid={`badge-rank-${rank}`}
                            >
                              #{rank}
                            </Badge>
                          </div>
                        ) : (
                          <div className="text-2xl font-semibold text-muted-foreground">
                            #{rank}
                          </div>
                        )}
                      </div>

                      <Avatar className="h-12 w-12">
                        <AvatarImage
                          src={entry.user.profileImageUrl || undefined}
                          alt={getUserDisplayName(entry.user)}
                          className="object-cover"
                        />
                        <AvatarFallback>
                          {getUserInitials(entry.user)}
                        </AvatarFallback>
                      </Avatar>

                      <div className="flex-1 min-w-0">
                        <h3
                          className="font-medium truncate"
                          data-testid={`text-username-${rank}`}
                        >
                          {getUserDisplayName(entry.user)}
                        </h3>
                        <div className="flex flex-wrap gap-3 mt-1 text-sm text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <TrendingUp className="h-3 w-3" />
                            {entry.solvedCount} solved
                          </span>
                          <span>•</span>
                          <span>{entry.acceptedCount} accepted</span>
                        </div>
                      </div>

                      <div className="hidden md:flex flex-col gap-2 min-w-[200px]">
                        <div>
                          <div className="flex items-center justify-between text-xs mb-1">
                            <span className="text-muted-foreground">Accuracy</span>
                            <span className="font-medium">
                              {entry.accuracy.toFixed(1)}%
                            </span>
                          </div>
                          <Progress value={entry.accuracy} className="h-2" />
                        </div>
                        <div>
                          <div className="flex items-center justify-between text-xs mb-1">
                            <span className="text-muted-foreground">Efficiency</span>
                            <span className="font-medium">
                              {entry.averageEfficiency.toFixed(1)}%
                            </span>
                          </div>
                          <Progress value={entry.averageEfficiency} className="h-2" />
                        </div>
                      </div>
                    </div>

                    <div className="md:hidden mt-3 space-y-2">
                      <div>
                        <div className="flex items-center justify-between text-xs mb-1">
                          <span className="text-muted-foreground">Accuracy</span>
                          <span className="font-medium">
                            {entry.accuracy.toFixed(1)}%
                          </span>
                        </div>
                        <Progress value={entry.accuracy} className="h-2" />
                      </div>
                      <div>
                        <div className="flex items-center justify-between text-xs mb-1">
                          <span className="text-muted-foreground">Efficiency</span>
                          <span className="font-medium">
                            {entry.averageEfficiency.toFixed(1)}%
                          </span>
                        </div>
                        <Progress value={entry.averageEfficiency} className="h-2" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })
          ) : (
            <Card>
              <CardContent className="p-8 text-center">
                <p className="text-muted-foreground">
                  No leaderboard data yet. Start solving problems to compete!
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
