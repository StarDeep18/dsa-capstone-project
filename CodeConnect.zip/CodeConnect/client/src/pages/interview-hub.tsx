import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import type { InterviewExperience } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Search, Plus, Briefcase, Calendar, Building2 } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function InterviewHub() {
  const [searchQuery, setSearchQuery] = useState("");
  const [difficultyFilter, setDifficultyFilter] = useState<string>("all");
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const { toast } = useToast();

  const [newExperience, setNewExperience] = useState({
    company: "",
    role: "",
    topics: "",
    difficulty: "medium",
    experience: "",
    interviewDate: "",
  });

  const { data: experiences, isLoading } = useQuery<InterviewExperience[]>({
    queryKey: ["/api/interview-experiences"],
  });

  const addMutation = useMutation({
    mutationFn: async (data: any) => {
      const topicsArray = data.topics.split(",").map((t: string) => t.trim()).filter(Boolean);
      const res = await apiRequest("POST", "/api/interview-experiences", {
        ...data,
        topics: topicsArray,
        interviewDate: data.interviewDate || null,
      });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/interview-experiences"] });
      setIsAddDialogOpen(false);
      setNewExperience({
        company: "",
        role: "",
        topics: "",
        difficulty: "medium",
        experience: "",
        interviewDate: "",
      });
      toast({
        title: "Success",
        description: "Interview experience added successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to add interview experience",
        variant: "destructive",
      });
    },
  });

  const filteredExperiences = experiences?.filter((exp) => {
    const matchesSearch =
      exp.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
      exp.role.toLowerCase().includes(searchQuery.toLowerCase()) ||
      exp.topics.some((topic) => topic.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesDifficulty = difficultyFilter === "all" || exp.difficulty === difficultyFilter;
    return matchesSearch && matchesDifficulty;
  });

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "easy":
        return "bg-chart-2/10 text-chart-2 border-chart-2/20";
      case "medium":
        return "bg-chart-3/10 text-chart-3 border-chart-3/20";
      case "hard":
        return "bg-chart-5/10 text-chart-5 border-chart-5/20";
      default:
        return "";
    }
  };

  return (
    <div className="flex-1 overflow-auto p-4 md:p-6 lg:p-8">
      <div className="mx-auto max-w-6xl">
        <div className="mb-6 flex items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-semibold mb-2">Interview Hub</h1>
            <p className="text-muted-foreground">
              Real interview experiences from top companies
            </p>
          </div>
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button data-testid="button-add-experience">
                <Plus className="mr-2 h-4 w-4" />
                Share Experience
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Share Your Interview Experience</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <div>
                    <label className="text-sm font-medium mb-2 block">Company</label>
                    <Input
                      value={newExperience.company}
                      onChange={(e) =>
                        setNewExperience({ ...newExperience, company: e.target.value })
                      }
                      placeholder="e.g., Google"
                      data-testid="input-company"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-2 block">Role</label>
                    <Input
                      value={newExperience.role}
                      onChange={(e) =>
                        setNewExperience({ ...newExperience, role: e.target.value })
                      }
                      placeholder="e.g., Software Engineer"
                      data-testid="input-role"
                    />
                  </div>
                </div>
                <div>
                  <label className="text-sm font-medium mb-2 block">
                    Topics (comma-separated)
                  </label>
                  <Input
                    value={newExperience.topics}
                    onChange={(e) =>
                      setNewExperience({ ...newExperience, topics: e.target.value })
                    }
                    placeholder="e.g., arrays, dynamic-programming, system-design"
                    data-testid="input-topics"
                  />
                </div>
                <div className="grid gap-4 md:grid-cols-2">
                  <div>
                    <label className="text-sm font-medium mb-2 block">Difficulty</label>
                    <Select
                      value={newExperience.difficulty}
                      onValueChange={(value) =>
                        setNewExperience({ ...newExperience, difficulty: value })
                      }
                    >
                      <SelectTrigger data-testid="select-difficulty">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="easy">Easy</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="hard">Hard</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-2 block">
                      Interview Date (optional)
                    </label>
                    <Input
                      type="date"
                      value={newExperience.interviewDate}
                      onChange={(e) =>
                        setNewExperience({ ...newExperience, interviewDate: e.target.value })
                      }
                      data-testid="input-date"
                    />
                  </div>
                </div>
                <div>
                  <label className="text-sm font-medium mb-2 block">
                    Your Experience
                  </label>
                  <Textarea
                    value={newExperience.experience}
                    onChange={(e) =>
                      setNewExperience({ ...newExperience, experience: e.target.value })
                    }
                    placeholder="Share your interview experience, questions asked, tips, etc."
                    className="min-h-[150px]"
                    data-testid="textarea-experience"
                  />
                </div>
                <Button
                  onClick={() => addMutation.mutate(newExperience)}
                  disabled={
                    !newExperience.company ||
                    !newExperience.role ||
                    !newExperience.topics ||
                    !newExperience.experience ||
                    addMutation.isPending
                  }
                  className="w-full"
                  data-testid="button-submit-experience"
                >
                  {addMutation.isPending ? "Submitting..." : "Submit Experience"}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search by company, role, or topic..."
              className="pl-9"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              data-testid="input-search"
            />
          </div>
          <Select value={difficultyFilter} onValueChange={setDifficultyFilter}>
            <SelectTrigger className="w-full sm:w-[160px]" data-testid="select-filter-difficulty">
              <SelectValue placeholder="Difficulty" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Levels</SelectItem>
              <SelectItem value="easy">Easy</SelectItem>
              <SelectItem value="medium">Medium</SelectItem>
              <SelectItem value="hard">Hard</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-4">
          {isLoading ? (
            Array.from({ length: 3 }).map((_, i) => (
              <Card key={i}>
                <CardHeader>
                  <Skeleton className="h-6 w-48" />
                </CardHeader>
                <CardContent>
                  <Skeleton className="h-20 w-full" />
                </CardContent>
              </Card>
            ))
          ) : filteredExperiences && filteredExperiences.length > 0 ? (
            filteredExperiences.map((exp) => (
              <Card key={exp.id} className="hover-elevate" data-testid={`card-experience-${exp.id}`}>
                <CardHeader>
                  <CardTitle className="flex flex-wrap items-center gap-3">
                    <div className="flex items-center gap-2">
                      <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                        <Building2 className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span>{exp.company}</span>
                          <Badge
                            variant="outline"
                            className={getDifficultyColor(exp.difficulty)}
                          >
                            {exp.difficulty}
                          </Badge>
                        </div>
                        <p className="text-sm font-normal text-muted-foreground">
                          {exp.role}
                        </p>
                      </div>
                    </div>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex flex-wrap gap-2">
                    {exp.topics.map((topic) => (
                      <Badge key={topic} variant="secondary" className="text-xs">
                        {topic}
                      </Badge>
                    ))}
                  </div>
                  <p className="text-sm text-muted-foreground line-clamp-3">
                    {exp.experience}
                  </p>
                  {exp.interviewDate && (
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <Calendar className="h-3 w-3" />
                      {new Date(exp.interviewDate).toLocaleDateString()}
                    </div>
                  )}
                </CardContent>
              </Card>
            ))
          ) : (
            <Card>
              <CardContent className="p-8 text-center">
                <Briefcase className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
                <p className="text-muted-foreground">
                  {searchQuery || difficultyFilter !== "all"
                    ? "No experiences match your filters"
                    : "No interview experiences yet. Be the first to share!"}
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
