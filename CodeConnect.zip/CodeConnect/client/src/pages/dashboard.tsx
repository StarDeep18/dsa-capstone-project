import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import type { Submission } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { TrendingUp, Trophy, Target, CheckCircle, Clock } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

interface DashboardStats {
  totalSolved: number;
  totalAccepted: number;
  accuracy: number;
  recentSubmissions: Submission[];
}

export default function Dashboard() {
  const { user } = useAuth();

  const { data: stats, isLoading } = useQuery<DashboardStats>({
    queryKey: ["/api/dashboard"],
  });

  const getUserDisplayName = () => {
    if (user?.firstName && user?.lastName) {
      return `${user.firstName} ${user.lastName}`;
    }
    if (user?.firstName) return user.firstName;
    if (user?.email) return user.email.split("@")[0];
    return "User";
  };

  const getUserInitials = () => {
    if (user?.firstName && user?.lastName) {
      return `${user.firstName[0]}${user.lastName[0]}`.toUpperCase();
    }
    if (user?.firstName) return user.firstName.slice(0, 2).toUpperCase();
    if (user?.email) return user.email.slice(0, 2).toUpperCase();
    return "??";
  };

  return (
    <div className="flex-1 overflow-auto p-4 md:p-6 lg:p-8">
      <div className="mx-auto max-w-7xl">
        <div className="mb-6 flex items-center gap-4">
          <Avatar className="h-16 w-16">
            <AvatarImage
              src={user?.profileImageUrl || undefined}
              alt={getUserDisplayName()}
              className="object-cover"
            />
            <AvatarFallback className="text-lg">
              {getUserInitials()}
            </AvatarFallback>
          </Avatar>
          <div>
            <h1 className="text-3xl font-semibold" data-testid="text-user-name">
              {getUserDisplayName()}
            </h1>
            <p className="text-muted-foreground">
              Track your progress and achievements
            </p>
          </div>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 mb-6">
          {isLoading ? (
            Array.from({ length: 4 }).map((_, i) => (
              <Card key={i}>
                <CardContent className="p-6">
                  <Skeleton className="h-12 w-12 mb-3" />
                  <Skeleton className="h-4 w-24 mb-2" />
                  <Skeleton className="h-8 w-16" />
                </CardContent>
              </Card>
            ))
          ) : (
            <>
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="h-12 w-12 rounded-md bg-primary/10 flex items-center justify-center">
                      <TrendingUp className="h-6 w-6 text-primary" />
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground mb-1">Total Solved</p>
                  <p className="text-3xl font-semibold" data-testid="text-total-solved">
                    {stats?.totalSolved || 0}
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="h-12 w-12 rounded-md bg-chart-2/10 flex items-center justify-center">
                      <CheckCircle className="h-6 w-6 text-chart-2" />
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground mb-1">Accepted</p>
                  <p className="text-3xl font-semibold" data-testid="text-total-accepted">
                    {stats?.totalAccepted || 0}
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="h-12 w-12 rounded-md bg-chart-3/10 flex items-center justify-center">
                      <Target className="h-6 w-6 text-chart-3" />
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground mb-1">Accuracy</p>
                  <p className="text-3xl font-semibold" data-testid="text-accuracy">
                    {stats?.accuracy.toFixed(1) || 0}%
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="h-12 w-12 rounded-md bg-chart-4/10 flex items-center justify-center">
                      <Trophy className="h-6 w-6 text-chart-4" />
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground mb-1">Success Rate</p>
                  <p className="text-3xl font-semibold">
                    {stats?.totalSolved
                      ? ((stats.totalAccepted / stats.totalSolved) * 100).toFixed(0)
                      : 0}%
                  </p>
                </CardContent>
              </Card>
            </>
          )}
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              Recent Activity
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-3">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Skeleton key={i} className="h-16 w-full" />
                ))}
              </div>
            ) : stats?.recentSubmissions && stats.recentSubmissions.length > 0 ? (
              <div className="space-y-3">
                {stats.recentSubmissions.map((submission) => (
                  <div
                    key={submission.id}
                    className="flex items-center justify-between p-3 rounded-md bg-muted/50 hover-elevate"
                    data-testid={`submission-${submission.id}`}
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className={`h-2 w-2 rounded-full ${
                          submission.status === "accepted"
                            ? "bg-chart-2"
                            : "bg-chart-5"
                        }`}
                      />
                      <div>
                        <p className="font-medium text-sm">Problem ID: {submission.problemId}</p>
                        <div className="flex items-center gap-2 mt-1">
                          <Badge variant="secondary" className="text-xs">
                            {submission.language}
                          </Badge>
                          <span className="text-xs text-muted-foreground">
                            {submission.passedTestCases}/{submission.totalTestCases} passed
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <Badge
                        variant={submission.status === "accepted" ? "default" : "destructive"}
                        className="text-xs"
                      >
                        {submission.status}
                      </Badge>
                      <p className="text-xs text-muted-foreground mt-1">
                        {new Date(submission.createdAt!).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-center text-muted-foreground py-8">
                No recent activity. Start solving problems to see your progress here!
              </p>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
