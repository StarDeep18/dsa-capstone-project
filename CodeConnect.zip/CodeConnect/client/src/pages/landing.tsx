import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Code, Trophy, Users, Briefcase, TrendingUp, Target } from "lucide-react";
import { ThemeToggle } from "@/components/theme-toggle";

export default function Landing() {
  return (
    <div className="min-h-screen bg-background">
      <header className="fixed top-0 left-0 right-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto flex h-16 items-center justify-between px-4">
          <div className="flex items-center gap-2">
            <Code className="h-6 w-6 text-primary" />
            <span className="text-xl font-semibold">CodeConnect</span>
          </div>
          <div className="flex items-center gap-2">
            <ThemeToggle />
            <Button asChild data-testid="button-login">
              <a href="/api/login">Sign In</a>
            </Button>
          </div>
        </div>
      </header>

      <main className="pt-16">
        <section className="container mx-auto px-4 py-20 md:py-32">
          <div className="mx-auto max-w-4xl text-center">
            <h1 className="text-4xl font-semibold md:text-5xl lg:text-6xl mb-6">
              Master DSA & Ace Your Interviews
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              CodeConnect is your all-in-one collaborative platform for coding practice, group challenges, 
              mentorship, and competitive analytics. Practice in Java, Python, and C to boost your DSA mastery 
              and real-world readiness.
            </p>
            <Button size="lg" asChild data-testid="button-get-started">
              <a href="/api/login">Get Started Free</a>
            </Button>
          </div>
        </section>

        <section className="container mx-auto px-4 py-16">
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 max-w-6xl mx-auto">
            <Card className="hover-elevate">
              <CardContent className="p-6">
                <div className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-md bg-primary/10">
                  <Code className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Multi-Language Practice</h3>
                <p className="text-muted-foreground">
                  Practice coding problems in Java, Python, and C with our intelligent code editor and 
                  instant feedback system.
                </p>
              </CardContent>
            </Card>

            <Card className="hover-elevate">
              <CardContent className="p-6">
                <div className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-md bg-chart-2/10">
                  <Trophy className="h-6 w-6 text-chart-2" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Group Leaderboard</h3>
                <p className="text-muted-foreground">
                  Compete with peers and track your progress on our real-time leaderboard ranked by 
                  efficiency and accuracy.
                </p>
              </CardContent>
            </Card>

            <Card className="hover-elevate">
              <CardContent className="p-6">
                <div className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-md bg-chart-3/10">
                  <Users className="h-6 w-6 text-chart-3" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Peer Comparison</h3>
                <p className="text-muted-foreground">
                  Compare your solved problems and code efficiency metrics with other users using 
                  our O(N) optimized comparison engine.
                </p>
              </CardContent>
            </Card>

            <Card className="hover-elevate">
              <CardContent className="p-6">
                <div className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-md bg-chart-4/10">
                  <Briefcase className="h-6 w-6 text-chart-4" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Interview Hub</h3>
                <p className="text-muted-foreground">
                  Access real interview experiences from top companies. Search and filter by company, 
                  role, and topic.
                </p>
              </CardContent>
            </Card>

            <Card className="hover-elevate">
              <CardContent className="p-6">
                <div className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-md bg-chart-5/10">
                  <TrendingUp className="h-6 w-6 text-chart-5" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Performance Analytics</h3>
                <p className="text-muted-foreground">
                  Track your time and space complexity metrics, submission history, and improvement 
                  trends over time.
                </p>
              </CardContent>
            </Card>

            <Card className="hover-elevate">
              <CardContent className="p-6">
                <div className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-md bg-primary/10">
                  <Target className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Competitive Edge</h3>
                <p className="text-muted-foreground">
                  Leverage DSA-optimized algorithms for leaderboard ranking, problem comparisons, 
                  and topic prioritization.
                </p>
              </CardContent>
            </Card>
          </div>
        </section>

        <section className="container mx-auto px-4 py-16 pb-20">
          <div className="mx-auto max-w-3xl text-center">
            <h2 className="text-3xl font-semibold mb-4">Ready to Level Up Your Coding Skills?</h2>
            <p className="text-lg text-muted-foreground mb-8">
              Join thousands of students mastering DSA and preparing for technical interviews with CodeConnect.
            </p>
            <Button size="lg" asChild data-testid="button-start-learning">
              <a href="/api/login">Start Learning Now</a>
            </Button>
          </div>
        </section>
      </main>

      <footer className="border-t py-8">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          <p>&copy; {new Date().getFullYear()} CodeConnect. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
