import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Users, Loader2, GitCompare } from "lucide-react";
import { Progress } from "@/components/ui/progress";

interface ComparisonResult {
  user1: {
    id: string;
    email: string | null;
    firstName: string | null;
    lastName: string | null;
    profileImageUrl: string | null;
    solvedCount: number;
    acceptedCount: number;
    accuracy: number;
    uniqueProblems: string[];
  };
  user2: {
    id: string;
    email: string | null;
    firstName: string | null;
    lastName: string | null;
    profileImageUrl: string | null;
    solvedCount: number;
    acceptedCount: number;
    accuracy: number;
    uniqueProblems: string[];
  };
  sharedProblems: string[];
}

export default function Compare() {
  const [userId1, setUserId1] = useState("");
  const [userId2, setUserId2] = useState("");
  const { toast } = useToast();

  const compareMutation = useMutation({
    mutationFn: async (data: { userId1: string; userId2: string }) => {
      const res = await apiRequest("POST", "/api/compare", data);
      return await res.json();
    },
    onError: () => {
      toast({
        title: "Comparison Failed",
        description: "Could not compare users. Please check the IDs and try again.",
        variant: "destructive",
      });
    },
  });

  const handleCompare = () => {
    if (!userId1.trim() || !userId2.trim()) {
      toast({
        title: "Missing Information",
        description: "Please enter both user IDs",
        variant: "destructive",
      });
      return;
    }
    compareMutation.mutate({ userId1: userId1.trim(), userId2: userId2.trim() });
  };

  const result = compareMutation.data as ComparisonResult | undefined;

  const getUserDisplayName = (user: ComparisonResult["user1"]) => {
    if (user.firstName && user.lastName) {
      return `${user.firstName} ${user.lastName}`;
    }
    if (user.firstName) return user.firstName;
    if (user.email) return user.email.split("@")[0];
    return "User";
  };

  const getUserInitials = (user: ComparisonResult["user1"]) => {
    if (user.firstName && user.lastName) {
      return `${user.firstName[0]}${user.lastName[0]}`.toUpperCase();
    }
    if (user.firstName) return user.firstName.slice(0, 2).toUpperCase();
    if (user.email) return user.email.slice(0, 2).toUpperCase();
    return "??";
  };

  return (
    <div className="flex-1 overflow-auto p-4 md:p-6 lg:p-8">
      <div className="mx-auto max-w-6xl">
        <div className="mb-6">
          <h1 className="text-3xl font-semibold mb-2">Compare Users</h1>
          <p className="text-muted-foreground">
            Side-by-side comparison of solved problems and performance metrics
          </p>
        </div>

        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4 items-end">
              <div className="flex-1">
                <label className="text-sm font-medium mb-2 block">User 1 ID</label>
                <Input
                  value={userId1}
                  onChange={(e) => setUserId1(e.target.value)}
                  placeholder="Enter user ID"
                  data-testid="input-user1"
                />
              </div>
              <div className="flex-1">
                <label className="text-sm font-medium mb-2 block">User 2 ID</label>
                <Input
                  value={userId2}
                  onChange={(e) => setUserId2(e.target.value)}
                  placeholder="Enter user ID"
                  data-testid="input-user2"
                />
              </div>
              <Button
                onClick={handleCompare}
                disabled={compareMutation.isPending}
                className="w-full md:w-auto"
                data-testid="button-compare"
              >
                {compareMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Comparing...
                  </>
                ) : (
                  <>
                    <GitCompare className="mr-2 h-4 w-4" />
                    Compare
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {result && (
          <div className="space-y-6">
            <div className="grid gap-6 lg:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-3">
                    <Avatar className="h-10 w-10">
                      <AvatarImage
                        src={result.user1.profileImageUrl || undefined}
                        alt={getUserDisplayName(result.user1)}
                        className="object-cover"
                      />
                      <AvatarFallback>
                        {getUserInitials(result.user1)}
                      </AvatarFallback>
                    </Avatar>
                    <span data-testid="text-user1-name">
                      {getUserDisplayName(result.user1)}
                    </span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Total Solved</p>
                      <p className="text-2xl font-semibold" data-testid="text-user1-solved">
                        {result.user1.solvedCount}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Accepted</p>
                      <p className="text-2xl font-semibold">
                        {result.user1.acceptedCount}
                      </p>
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center justify-between text-sm mb-2">
                      <span className="text-muted-foreground">Accuracy</span>
                      <span className="font-medium">
                        {result.user1.accuracy.toFixed(1)}%
                      </span>
                    </div>
                    <Progress value={result.user1.accuracy} />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground mb-2">
                      Unique Problems
                    </p>
                    <Badge variant="secondary" data-testid="badge-user1-unique">
                      {result.user1.uniqueProblems.length} problems
                    </Badge>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-3">
                    <Avatar className="h-10 w-10">
                      <AvatarImage
                        src={result.user2.profileImageUrl || undefined}
                        alt={getUserDisplayName(result.user2)}
                        className="object-cover"
                      />
                      <AvatarFallback>
                        {getUserInitials(result.user2)}
                      </AvatarFallback>
                    </Avatar>
                    <span data-testid="text-user2-name">
                      {getUserDisplayName(result.user2)}
                    </span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Total Solved</p>
                      <p className="text-2xl font-semibold" data-testid="text-user2-solved">
                        {result.user2.solvedCount}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Accepted</p>
                      <p className="text-2xl font-semibold">
                        {result.user2.acceptedCount}
                      </p>
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center justify-between text-sm mb-2">
                      <span className="text-muted-foreground">Accuracy</span>
                      <span className="font-medium">
                        {result.user2.accuracy.toFixed(1)}%
                      </span>
                    </div>
                    <Progress value={result.user2.accuracy} />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground mb-2">
                      Unique Problems
                    </p>
                    <Badge variant="secondary" data-testid="badge-user2-unique">
                      {result.user2.uniqueProblems.length} problems
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  Shared Problems
                </CardTitle>
              </CardHeader>
              <CardContent>
                {result.sharedProblems.length > 0 ? (
                  <div className="space-y-2">
                    <p className="text-sm text-muted-foreground mb-3">
                      Both users have solved these {result.sharedProblems.length} problems:
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {result.sharedProblems.map((problemId, index) => (
                        <Badge key={problemId} variant="outline" data-testid={`badge-shared-${index}`}>
                          Problem {index + 1}
                        </Badge>
                      ))}
                    </div>
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground">
                    No shared problems between these users
                  </p>
                )}
              </CardContent>
            </Card>
          </div>
        )}

        {!result && !compareMutation.isPending && (
          <Card>
            <CardContent className="p-12 text-center">
              <GitCompare className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">
                Enter two user IDs above to see a detailed comparison
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
